# TechSummit Microsoft Madrid2016

# 1.- Explorar datos y crear modelos con Rattle
#install.packages("rattle")
library("rattle")
rattle()

# 2.- Explorar datos y crear modelos con otros paquetes
### Conectar a datos externos
setwd("C:/TechSummit Madrid16 Patrones")
# Leer contenido de un fichero CSV a dataframe
df_dm <-read.table("ClientesDM.csv",header = TRUE, sep = ",")
 
### Primer vistazo a los datos 
# Examinar
View(df_dm)
# Examinar primeros valores
head(df_dm)
# Obtener resumen del conjunto de datos
summary(df_dm)

### Explorar mediante Gr�ficos
# Instalar y cargar paquete ggplot 
## install.packages("ggplot2", dependencies = TRUE)
# Cargar paquete ggplot 
library(ggplot2)

# Columnas apiladas Regi�n por Ocupaci�n
ggplot (df_dm, aes(Region, fill=Educacion)) + geom_bar()
ggplot (df_dm, aes(Region, fill=Educacion)) + geom_bar(position = "dodge")
# Caja Edad por Ocupaci�n
ggplot (df_dm, aes(Ocupacion, fill=Ocupacion, Edad)) + geom_point() + geom_boxplot()
#Histograma Edad
ggplot (df_dm, aes(Edad)) + geom_histogram(binwidth = 0.5)
ggplot (df_dm, aes(Edad)) + geom_density()

### Modelado

###############
# Naive Bayes #
###############

# Instalar paquete e1071 (Naive Bayes)
## install.packages("e1071", dependencies = TRUE)
# Cargar paquete e1071 
library(e1071)
# Eliminar columnas continuas
df_dm$Edad <- NULL
df_dm$Ingresos <- NULL
# Entrenar el modelo Naive Bayes
Modelo_NB <- naiveBayes(df_dm[,2:11], df_dm[,12])
# Data frame con las predicciones para todas las filas
df_NB <- as.data.frame(predict(Modelo_NB, df_dm, type = "raw"))
View(df_NB)
# Combinar datos originales con la predicci�n
df_DMNB <- cbind(df_dm, df_NB)
View(df_DMNB)


##################
# Decision Trees #
##################

# Instalar paquete party (Decision Trees)
## install.packages("party", dependencies = TRUE)
library("party")
# Entrenar el modelo
Modelo_DT <- ctree(Comprador ~ Coches + Region,
              data = df_dm)
# Mostrar los resultados
plot(Modelo_DT, type = "simple")


